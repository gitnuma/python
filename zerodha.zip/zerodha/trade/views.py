from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def portfolio(r):
    return HttpResponse('<h1> Welcome to Your Portfolio</h1>')